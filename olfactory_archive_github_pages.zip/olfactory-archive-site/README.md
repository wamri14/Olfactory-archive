# Olfactory Archive

A standalone fragrance dashboard with 157 entries from the personal Hall of Fame. The application has no external dependencies and runs on GitHub Pages.

## Publish on GitHub Pages

1. Create a new **public** repository on GitHub, for example `olfactory-archive`.
2. Upload `index.html` and `fragrance_hall_of_fame.md` to the repository root (use **Add file → Upload files**).
3. Open **Settings → Pages**. Under **Build and deployment**, choose **Deploy from a branch**, branch **main**, folder **/(root)**, and save.
4. After deployment, open `https://YOUR-USERNAME.github.io/olfactory-archive/` in Safari. It may take a few minutes to become available.

## Data and privacy

Ratings, tiers, tags and notes are stored in localStorage on the current browser/device. They are not automatically synchronized. Export JSON regularly to back up your edits. A public GitHub Pages site means the original fragrance list and website source are publicly viewable; personal notes stay on the device unless you export and upload them.

## Notes

The dashboard uses a decorative icon rather than official bottle photography. All fragrance records are preloaded; ratings and personal notes are initially empty.
